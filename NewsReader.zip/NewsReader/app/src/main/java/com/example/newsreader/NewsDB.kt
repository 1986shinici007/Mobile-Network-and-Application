package com.example.newsreader

object NewsDB  {
    val Headlines = arrayOf(
        "Article One",
        "Article Two"
    )

    val Articles = arrayOf(
        "This is an awesome class!",
        "The instructor is awesome!"
    )
}