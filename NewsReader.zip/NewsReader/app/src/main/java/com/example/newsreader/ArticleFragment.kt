package com.example.newsreader

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class ArticleFragment : Fragment(R.layout.fragment_article) {
    private var newsId: Int? = null
    public fun updateContentView(position: Int){
        val textView = view as TextView
        textView.setText(NewsDB.Articles[position])
        newsId = position
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.let {
            val id = it.getInt("NEWS_ID")
            updateContentView(id)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        newsId?.let {
            outState.putInt("NEWS_ID", it)
        }
    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)
        savedInstanceState?.let {
            val id = it.getInt("NEWS_ID")
            updateContentView(id)
        }
    }
}