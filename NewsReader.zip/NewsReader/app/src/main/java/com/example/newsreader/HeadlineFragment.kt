package com.example.newsreader

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.fragment.app.ListFragment
import java.lang.Exception

class HeadlineFragment : ListFragment() {
    lateinit var listener: OnHeadlineClickListener
    // The container activity must implement this interface
    interface OnHeadlineClickListener {
        //used to notify the listener whenever a list item is selected
        fun onHeadlineClick(position: Int)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listAdapter = context?.let {
            ArrayAdapter<String>(
                it,
                android.R.layout.simple_list_item_activated_1,
                NewsDB.Headlines
            )
        }
    }

    override fun onListItemClick(l: ListView, v: View, position: Int, id: Long) {
        super.onListItemClick(l, v, position, id)
        listView.setItemChecked(position, true)
        listener.onHeadlineClick(position)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            listener = context as OnHeadlineClickListener
        } catch (e: Exception){
            e.printStackTrace()
        }
    }
}