package com.example.newsreader

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.example.newsreader.databinding.ActivityMainBinding
import androidx.fragment.app.FragmentTransaction

class MainActivity : AppCompatActivity(), HeadlineFragment.OnHeadlineClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = DataBindingUtil.setContentView(this, R.layout.activity_main) as ActivityMainBinding

        if (binding.fragmentContainer != null){
            if (savedInstanceState != null) return
            val headlineFragment = HeadlineFragment()
            supportFragmentManager.beginTransaction()
                .add(R.id.fragment_container, headlineFragment).commit()
        }

    }

    override fun onHeadlineClick(position: Int) {
        val fragment = supportFragmentManager.findFragmentById(R.id.articleView_fragment)

        if (fragment != null && fragment is ArticleFragment) {
            fragment.updateContentView(position)
        } else {
            val fragment = ArticleFragment()
            val args = Bundle()
            args.putInt("NEWS_ID", position)
            fragment.arguments = args

            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container,fragment)
            transaction.addToBackStack(null)
            transaction.commit()
        }
    }
}