package com.example.itunelistener

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class iTuneRecyclerViewAdapter(data: List<SongData>, val listener: RecyclerViewClickListener): RecyclerView.Adapter<iTuneRecyclerViewAdapter.ViewHolder>(){
    var songs:  List<SongData> = data
    set(value) {
        field = value
        notifyDataSetChanged()
    }

    interface RecyclerViewClickListener{
        fun onItemClick(view: View, position: Int)
    }

    class ViewHolder(val view: View, val listener: RecyclerViewClickListener): RecyclerView.ViewHolder(view), View.OnClickListener {
        val textView: TextView = view.findViewById(R.id.textView)
        val imageView: ImageView = view.findViewById(R.id.imageView)

        override fun onClick(p0: View?) {
            listener.onItemClick(view, absoluteAdapterPosition)
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.itune_list_item, parent, false)

        val holder = ViewHolder(view, listener)
        view.setOnClickListener(holder)
        return holder
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.imageView.setImageBitmap(songs[position].cover)
        holder.textView.text = songs[position].title
    }

    override fun getItemCount(): Int {
        return songs.size
    }
}