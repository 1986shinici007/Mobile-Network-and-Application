package com.example.itunelistener

import android.graphics.Bitmap

class SongData(val title: String, val cover: Bitmap?) {
}