package com.example.itunelistener

import android.app.ListActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity(), iTuneRecyclerViewAdapter.RecyclerViewClickListener {
//    val titles = mutableListOf<String>()
//    val adapter: ArrayAdapter<String> by lazy {
//       ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,titles)
//    }
//    val adapter: iTuneListViewAdapter by lazy {
//        iTuneListViewAdapter(this)
//}
    val adapter: iTuneRecyclerViewAdapter by lazy {
        iTuneRecyclerViewAdapter(listOf<SongData>(),this)
    }

    override fun onItemClick(view: View, position: Int) {
        Toast.makeText(this, adapter.songs[position].title, Toast.LENGTH_LONG).show()
    }

    val swipeRefreshLayout by lazy {
        findViewById<SwipeRefreshLayout>(R.id.swipeRefreshLayout)
    }

    private fun loadList(){
        iTuneSAX(object: ParserListener {
            override fun start() {
                swipeRefreshLayout.isRefreshing = true
            }

            override fun finish(songs: List<SongData>) {
//                for (song in songs){
//                    titles.add(song.title)
//                }
//                adapter.notifyDataSetChanged()
                adapter.songs = songs
                swipeRefreshLayout.isRefreshing = false
            }
        }).parseURL("https://www.youtube.com/feeds/videos.xml?channel_id=UCupvZG-5ko_eiXAupbDfxWw")
        //parseURL("https://www.youtube.com/feeds/videos.xml?channel_id=UCupvZG-5ko_eiXAupbDfxWw")
        //parseURL("http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topsongs/limit=25/xml")
    }

//    override fun onListItemClick(l: ListView?, v: View?, position: Int, id: Long) {
//        super.onListItemClick(l, v, position, id)
//        //Toast.makeText(this, titles[position], Toast.LENGTH_LONG).show()
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        setContentView(R.layout.activity_swipe_refresh)
        //listAdapter = adapter

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.addItemDecoration(DividerItemDecoration (
            recyclerView.context,
            DividerItemDecoration.VERTICAL))


        //Refresh
        swipeRefreshLayout.setOnRefreshListener{
            //titles.clear()
            loadList()
        }
        loadList()
    }
}