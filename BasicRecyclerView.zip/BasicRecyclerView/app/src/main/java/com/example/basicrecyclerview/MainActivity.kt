package com.example.basicrecyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity(), MyAdapter.OnClickListener {
    val data = arrayOf("Apple", "Banana", "Cherry", "Orange")
    private lateinit var recyclerView: RecyclerView
    private lateinit var viewManager: RecyclerView.LayoutManager
    private lateinit var viewAdapter: MyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewManager = LinearLayoutManager(this)
        viewAdapter = MyAdapter(data, this)

        recyclerView = findViewById<RecyclerView>(R.id.recyclerView).apply {
            //use a linear layout manager
            layoutManager = viewManager
            adapter = viewAdapter
        }
    }

    override fun onClick(position: Int) {
        Toast.makeText(this, data[position], Toast.LENGTH_LONG).show()
    }
}