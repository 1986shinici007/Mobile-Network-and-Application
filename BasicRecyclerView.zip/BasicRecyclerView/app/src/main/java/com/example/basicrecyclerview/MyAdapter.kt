package com.example.basicrecyclerview

import android.service.autofill.Dataset
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyAdapter (private val myDataset: Array<String>, val listener: OnClickListener) :
    RecyclerView.Adapter<MyAdapter.MyViewHolder>() {
        class MyViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyAdapter.MyViewHolder {
        //create a new view
        val textView = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_1,parent,false) as TextView
        return MyViewHolder(textView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        holder.textView.text = myDataset[position]
        holder.itemView.setOnClickListener{
            listener.onClick(position)
        }
    }

    override fun getItemCount() = myDataset.size

    interface OnClickListener {
        fun onClick(position: Int)
    }
}