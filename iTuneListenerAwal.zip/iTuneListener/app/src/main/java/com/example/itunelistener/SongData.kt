package com.example.itunelistener

class SongData(val title: String = "") {
}