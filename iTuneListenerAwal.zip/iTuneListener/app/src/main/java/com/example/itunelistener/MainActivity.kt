package com.example.itunelistener

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val linearLayout = findViewById<LinearLayout>(R.id.linearlayout)

        iTuneSAX(object: ParserListener {
            override fun start() {
            }

            override fun finish(songs: List<SongData>) {
                for (song in songs){
                    val textView = TextView(this@MainActivity)
                    textView.text = song.title
                    linearLayout.addView(textView)
                }
            }
        }).parseURL("https://www.youtube.com/feeds/videos.xml?channel_id=UCupvZG-5ko_eiXAupbDfxWw")
    }
}