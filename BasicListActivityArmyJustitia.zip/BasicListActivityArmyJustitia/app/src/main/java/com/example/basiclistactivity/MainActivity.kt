package com.example.basiclistactivity

import androidx.appcompat.app.AppCompatActivity
import android.app.ListActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast

class MainActivity : ListActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val data = listOf("Apple", "Banana", "Cherry", "Orange")
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, data)
        setListAdapter (adapter)

    }
    override fun onListItemClick(l: ListView?, v: View?, position: Int, id: Long) {
        super.onListItemClick(l, v, position, id)
        val fruit = listAdapter.getItem(position) as String
        Toast.makeText(this, fruit, Toast.LENGTH_SHORT).show()
    }
}