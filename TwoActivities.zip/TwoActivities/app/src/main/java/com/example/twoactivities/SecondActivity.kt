package com.example.twoactivities

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView

class SecondActivity : AppCompatActivity() {
    private val LOG_TAG = SecondActivity::class.java.simpleName
    companion object {
        val EXTRA_REPLY = "com.example.twoactivities.extra.REPLY"
    }
    private var mReply: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        mReply = findViewById<EditText>(R.id.editText_second)

        val message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        val textView: TextView = findViewById(R.id.text_message);
        textView.text = message;
    }

    override fun onStart() {
        super.onStart()
        Log.d(LOG_TAG, "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d(LOG_TAG,"onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d(LOG_TAG,"onPause")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(LOG_TAG,"onRestart")
    }

    override fun onStop() {
        super.onStop()
        Log.d(LOG_TAG, "onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(LOG_TAG,"onDestroy")
    }

    fun returnReply(view: View) {
        val reply = mReply!!.text.toString()
        val replyIntent = Intent()

        replyIntent.putExtra(EXTRA_REPLY, reply)
        setResult(Activity.RESULT_OK, replyIntent)
        Log.d(LOG_TAG,"End Second Activity")
        finish()
    }
}