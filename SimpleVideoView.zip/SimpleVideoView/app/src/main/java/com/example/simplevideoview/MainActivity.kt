package com.example.simplevideoview

import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PersistableBundle
import android.webkit.URLUtil
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    //private val VIDEO_SAMPLE = "big_buck_bunny"
    private val VIDEO_SAMPLE = "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4"
    private lateinit var mVideoView: VideoView
    private var mCurrentPosition = 0
    private val PLAYBACK_TIME = "play_time"
    private lateinit var mBufferingTextView: TextView

    private fun getMedia(mediaName: String): Uri? {
        if (URLUtil.isValidUrl(mediaName)) {
            // media name is an external URL
            return Uri.parse(mediaName);
        } else { // media name is a raw resource embedded in the app
            return Uri.parse(
                "android.resource://" + getPackageName() +
                        "/raw/" + mediaName
            );
        }
        /*return Uri.parse(
            "android.resource://" + packageName +
                    "/raw/" + mediaName
        )*/

    }

    private fun initializePlayer() {
        mBufferingTextView.setVisibility(VideoView.INVISIBLE);
        val videoUri = getMedia(VIDEO_SAMPLE)
        mVideoView.setVideoURI(videoUri)
        if (mCurrentPosition > 0) {
            mVideoView.seekTo(mCurrentPosition);
        } else {
            // Skipping to 1 shows the first frame of the video.
            mVideoView.seekTo(1);
        }

        mVideoView.start()
        mVideoView.setOnPreparedListener {
            // Implementation here.
            mBufferingTextView.visibility = VideoView.INVISIBLE
            if (mCurrentPosition > 0) {
                mVideoView.seekTo(mCurrentPosition)
            } else {
                mVideoView.seekTo(1)
            }
            mVideoView.start()
        }
        mVideoView.setOnCompletionListener {
            Toast.makeText(
                this@MainActivity, "Playback completed",
                Toast.LENGTH_SHORT
            ).show()
            mVideoView.seekTo(1)
        }
    }

    private fun releasePlayer() {
        mVideoView.stopPlayback()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(PLAYBACK_TIME, mVideoView.currentPosition)
    }

    override fun onStart() {
        super.onStart()
        initializePlayer()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    override fun onPause() {
        super.onPause()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            mVideoView.pause()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mVideoView = findViewById(R.id.videoview)
        val controller = MediaController(this)
        controller.setMediaPlayer(mVideoView)
        mVideoView.setMediaController(controller)
        if (savedInstanceState !=null ){
            mCurrentPosition = savedInstanceState.getInt(PLAYBACK_TIME)
        }
        mBufferingTextView = findViewById(R.id.buffering_textview);

        /*val videoView=findViewById<VideoView>(R.id.videoview)
        val mediaController = MediaController(this)
        mediaController.setAnchorView(videoView)

        val offlineUri= Uri.parse("android.resource://${R.raw.big_buck_bunny}")

        videoView.setMediaController(mediaController)
        videoView.setVideoURI(offlineUri)
        videoView.requestFocus()
        videoView.start()*/
    }
}